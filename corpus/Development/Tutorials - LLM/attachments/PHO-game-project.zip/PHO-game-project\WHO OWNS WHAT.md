# Who owns what

Anthony — code, interaction system, builds, UI, scheduling (?)

Deloris — environment, narrative, lighting, audio, presentation

Shared — core design, playtests, documentation, source control

Old plan said Deloris would own Git because she set up the repo. New plan says Anthony owns builds because only his project opens without pink materials. This is not the same thing, but we keep treating it like it is.

Mina — friend who may compose one loop if there is time. Not formally on team.
