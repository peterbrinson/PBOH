# 9/16 meeting notes (Deloris typed during call)

ANTHONY DEMO
- movement feels clear
- highlight works
- ticket tells player exact recipe (removes deduction??)
- timer makes D rush past room details
- chopping works but is currently the most prominent interaction

DELORIS CAMERA TEST
- overhead composition beautiful
- player character needs animation we don't have
- hard to read small table clues
- zoom/camera collision extra work

PROVISIONAL CAMERA DECISION
Use first person for vertical slice because it exists and supports close looking. Keep overhead as a post-showcase exploration, not a promise.

SCOPE
Someone in critique said choose what the player is meant to care about. We keep saying “cooking deduction” and “story ritual” interchangeably.

NEXT
- D makes clue sheet
- A makes three-choice bowl variant
- remove visible ticket instructions; table clue can replace
- test with no timer

Did we officially cut score? I thought yes. A said “hide it for test,” which may not mean cut.
