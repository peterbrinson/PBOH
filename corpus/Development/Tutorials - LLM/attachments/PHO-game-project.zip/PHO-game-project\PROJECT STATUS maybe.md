# PHO project status — Oct 2?

We have a playable restaurant blockout on Anthony's laptop. You can walk, inspect six props, pick ingredients, assemble a bowl, and ring the service bell. The ending is still placeholder text.

What I think is current:

- Unity URP
- one restaurant
- first person for now
- one last order
- Windows build first
- no chopping minigame
- no voice acting unless the festival version happens

Still weird:

- Anthony's prototype still displays a countdown and score even though we cut those at scope lock.
- Deloris's newest storyboard assumes we see the protagonist from above.
- the ingredient list in the build does not match the story clue sheet
- title?? PHO / Last Bowl / After Hours

This is not an official decision log. I am writing it because we do not have one.

— probably Deloris
