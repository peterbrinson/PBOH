# What is current?

This folder was created because we could not answer that question quickly.

Likely sources, newest first:

1. `notes and meetings/scope lock 9-22.md`
2. `design/GDD_v2_FINAL.md`
3. `development/tech-plan.md`
4. `planning/Schedule_REVISED.csv`
5. `development/KNOWN BUGS.md`

But do not assume one file covers everything. Later chat and playtest notes contain implementation changes and unresolved disagreements.

Needed from handoff person:

- a current project brief with source citations
- a timeline of decisions
- Anthony's view and Deloris's view, represented fairly
- a list of resolved contradictions versus open conflicts
- a risk list
- a proposed folder structure that preserves the archive
