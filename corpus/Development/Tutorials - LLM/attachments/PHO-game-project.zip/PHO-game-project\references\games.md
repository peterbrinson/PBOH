# Game references — shared list

## Strong references

### Venba

Food preparation carries family history and relationship. We should discuss how instructions, error, and memory are represented without copying its interface or cultural specifics.

### Unpacking

Ordinary object placement can reveal a person without exposition. Deloris's clues should work this way: the player notices spatial evidence, not collectible lore dumps.

### Papers, Please

Repeated cases teach a system and make small discrepancies meaningful. Anthony sees this as support for multiple customers; Deloris thinks its pressure and institutional tone are wrong for our slice.

### The Red Strings Club

Making an object for a person can become a form of conversation. Relevant to bowl assembly and customer response.

## Useful but dangerous

### Overcooked

Excellent station readability and feedback; wrong pace, comic tone, and multiplayer assumptions.

### Gone Home

Environmental inference and intimate space; risk that interaction becomes only clicking text.

### Coffee Talk

Serving drinks as social/narrative structure; dialogue-heavy, which we cut.

## Team question

Which references describe the player's verbs, which describe tone, and which only describe our hoped-for emotional effect? We keep mixing these categories.
