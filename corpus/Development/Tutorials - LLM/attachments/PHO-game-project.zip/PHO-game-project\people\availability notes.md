# Availability, maybe current

Anthony
- Mon/Wed mornings
- Tue after 6
- unavailable Sept 28–30
- wants a 15-minute standup at 10:00

Deloris
- Mon/Wed after 3
- Tue/Thu afternoons
- unavailable Oct 7
- cannot do 10:00 standups because of work

Shared overlap: Wednesday 4:00–5:30, except playtest week.

The `Schedule_REVISED.csv` assigns integration meetings Tuesday at 10:00. That time came from Anthony's template and was never confirmed.
