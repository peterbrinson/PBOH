# Lantern Student Games Showcase — application draft

**Game title:** PHO: Last Bowl  
**Team:** Anthony and Deloris  
**Genre:** narrative cooking puzzle  
**Platform:** Nintendo Switch / PC  
**Estimated playtime:** 15–20 minutes

In PHO: Last Bowl, players operate a tiny restaurant visited by spirits. Each order is a puzzle whose ingredients reveal the customer's unfinished story. Use tactile cooking actions, dialogue choices, and environmental clues to serve three supernatural guests before dawn.

## Features

- Three fully voiced customers
- Expressive overhead presentation
- Branching endings
- Original soundtrack
- Accessible controller-first play

NOTE FROM A: this is aspirational copy. Do not send until we know what “showcase ready” means.

NOTE FROM D: application deadline is before our vertical slice, so some aspiration is unavoidable. But cut Switch if we cannot test it.
