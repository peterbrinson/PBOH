# Deloris

## Comfortable with

- Blender environment modeling
- composition, lighting, and materials
- environmental narrative
- storyboards and level flow
- audio editing
- presenting and running playtests

## Less comfortable with

- C# architecture
- build settings
- source-control conflict resolution
- estimating implementation time

## Working preferences

- late-afternoon collaboration
- visual boards and scene walk-throughs
- leave names flexible until the experience has a tone
- author one finished path before building a general system
- talk through disagreement live, then write down the decision

Deloris uses “final” to mean “the version I am presenting today,” not “locked forever.”
