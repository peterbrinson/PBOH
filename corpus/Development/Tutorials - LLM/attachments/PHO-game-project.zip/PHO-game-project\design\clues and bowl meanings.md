# Clues and bowl meanings

**Deloris working sheet — Sept 24**

## Restaurant clues

### Repaired chair

The window chair has been repaired repeatedly. The customer returns even when the place changes. This should suggest continuity, not poverty.

### Umbrella

Old yellow umbrella, still wet. A transit tag is looped around the handle. Suggests they came in during rain and perhaps left in a hurry.

### Marked menu

One item is circled, then crossed out, then circled again in different ink. I want ambiguity: habit versus a desire to change.

### Receipt stack

Receipts on the pin show the same table over several years. The name changes from “M.” to “Mae” only in the final months.

## Ingredient interpretations

- **clear broth** — preserve the familiar
- **spiced broth** — offer warmth / change
- **basil** — what they usually asked for
- **cilantro** — what the cook remembers from the first visit
- **lime** — brightness, interruption, unfinished gesture
- **chili oil** — Anthony says this should be high-risk/high-reward; I do not know what that means narratively

## Current build mismatch

Anthony's table uses `mint` where this sheet uses `basil`. If mint is intentional, we need a clue for it. If not, change the data.
