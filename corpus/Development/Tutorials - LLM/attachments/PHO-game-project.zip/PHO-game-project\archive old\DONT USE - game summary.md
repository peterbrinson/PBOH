# Game summary

PHO is a mobile free-to-play cooking game where players collect recipes and decorate a restaurant.

NOTE: this came from an AI name/market exercise and has never been our project. Keeping it because Anthony liked one sentence about “ingredients as emotional vocabulary,” but this summary should not be quoted.
