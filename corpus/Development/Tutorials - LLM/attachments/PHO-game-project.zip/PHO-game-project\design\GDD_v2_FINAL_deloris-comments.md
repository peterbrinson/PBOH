# GDD v2 comments after Anthony's build review

**Sept 26 — Deloris**

This copies the scope-lock version because the other file was open on Anthony's computer.

Things the build currently contradicts:

- 4:00 countdown still starts when the light turns on
- score screen calls ingredients CORRECT / INCORRECT
- player has to chop scallions six times
- five ingredient choices, not three
- no inspect text for umbrella or repaired chair
- service bell immediately spawns translucent customer model

Things I am willing to revise:

- We can keep first person through showcase.
- We can keep Anthony's general ingredient data structure even with one authored customer.
- A soft timing measure for internal analytics is fine if the player never sees it.

Things I do not think we decided:

- recipe has one objectively correct answer
- three customers for this milestone
- visible score
- ghost reveal

Anthony: please comment in one document rather than making GDD v3 on desktop.
