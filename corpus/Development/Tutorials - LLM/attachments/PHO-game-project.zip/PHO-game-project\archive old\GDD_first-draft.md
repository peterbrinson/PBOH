# GDD FIRST DRAFT — PHO

Cooperative restaurant roguelite for two players. One player cooks, one player interviews ghosts. Complete orders to keep the restaurant open for 30 nights.

- local co-op
- upgrade kitchen between runs
- 20 ingredients
- procedural customer traits
- relationship meter
- boss customers
- Unity HDRP

Anthony note, later: Original jam brainstorm. Not current after team size became two developers and course scope became one prototype.
