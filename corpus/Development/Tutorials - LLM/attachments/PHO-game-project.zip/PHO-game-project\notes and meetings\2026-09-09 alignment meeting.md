# Alignment meeting — Sept 9

Present: A, D

We compared Anthony's system pitch and Deloris's Last Bowl pitch.

## Agreed

- vertical slice focuses on one customer/order
- data-driven ingredients are useful even for authored sequence
- room contains clues; player should inspect rather than receive full ticket
- Unity, likely URP
- no dialogue system in first slice

## Not agreed

- one correct recipe vs interpretive endings
- timer and score
- first-person vs overhead
- whether customer appears at end

## Prototype tests

Anthony: first-person interaction + ticket loop.  
Deloris: overhead room composition + clue storyboard.

Revisit after both tests. Do not expand content before camera test.

Side note: Anthony interpreted “one customer for vertical slice” as system designed for three later. Deloris interpreted it as project scope. We noticed this but did not resolve it.
