# phone notes — after scope lock

- Anthony is not wrong that players need to understand consequences
- I am not against systems; I am against the system telling them grief = 74%
- maybe receipts become more specific when choices connect to clues
- keep no literal ghost: empty chair is stronger
- if we must show ghost for interaction confirmation, use reflection only? probably still too literal
- first person accepted through showcase
- title LAST BOWL still better but festival searchability concern is fair
- restaurant should feel used, not “cozy pack” generic
- record rain ourselves? licensing risk
- ask Anthony to commit every day; I cannot decorate a local build
