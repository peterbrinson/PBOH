# Controls backup from overhead prototype

- left stick / WASD: move cursor or character
- A / click: walk to station
- X: use station
- Y: inspect clue
- shoulder buttons: cycle held ingredients
- right stick: rotate room camera

Deloris built this in a Figma clickthrough, not Unity. Do not treat as current implementation.
