# Build targets

Owner: Anthony

## Festival application says

- Nintendo Switch
- PC
- controller-first

## What we can actually make now

- Windows 10/11 x86_64
- 1920×1080, windowed option
- keyboard and mouse
- Xbox controller partially mapped; bowl placement cannot cancel

## Maybe

- macOS build if Deloris can borrow Mac lab time
- WebGL if build is under 200 MB

## Not planned

- Switch: no dev kit, no platform access, no test hardware
- mobile

The vertical-slice submission should say **Windows PC**. Please fix any pitch copy that says Switch.
