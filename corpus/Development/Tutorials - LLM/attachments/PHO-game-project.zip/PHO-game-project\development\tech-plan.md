# Technical plan

**Anthony — Sept 14, updated Sept 21**

## Engine

Unity 2022.3.48f1 LTS, Universal Render Pipeline. We chose this because both lab machines and Anthony's home machine have it, and because the interaction prototype already exists there.

Do not upgrade mid-project. Deloris accidentally opened a copy in 2023.2 and committed material changes; that copy is not authoritative.

## Target

Windows x86_64 for vertical slice. WebGL was discussed but audio, post-processing, and file-size work are not scheduled. Controller support after keyboard/mouse interaction is stable.

## Scene structure

- `Boot`
- `Restaurant_Blockout`
- `Restaurant_Lighting` (Deloris's test; merge into blockout after review)
- `EndReceipt`

## Systems

- `Interactable` base component
- raycast focus from camera
- `IngredientDefinition` ScriptableObjects
- three-slot `BowlAssembly`
- `ClueState` stores inspected objects
- `EndingResolver` maps ingredient story tags + inspected clues to receipt line

## Save data

No save system for vertical slice. Session state resets on restart. The older GDD mentions persistent clue discovery; that is cut.

## Source control

Git repository exists but large assets are being passed in Drive because LFS was not configured. Fix before adding final audio.
