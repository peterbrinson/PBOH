# Milestones

## Vertical slice

**Internal date:** Oct 6  
**Current interpretation:** one complete order from entering restaurant to receipt ending.

Required:

- room reads as restaurant at night
- three inspectable clues
- three ingredient choices
- bowl assembly
- service bell and ending
- Windows build another person can launch

Not required:

- multiple customers
- save system
- voice acting
- final music
- controller
- festival title lock? (probably required for form, not build)

## Lantern showcase candidate

One schedule says Oct 10, one says Oct 12. Application email copied in chat says uploads close **Oct 12 at noon**, but our team wanted a stable build by **Oct 10 at 6 p.m.** Both dates may be real.

Showcase candidate adds bug fixes, subtitles, controller if stable, and two more receipt variations.
