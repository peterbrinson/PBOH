# Playtest 1 summary — build 0.2

**Date:** Sept 17  
**Facilitator:** Anthony

## Findings

- 5/5 understood how to assemble a bowl.
- 4/5 completed or nearly completed within six minutes.
- Ingredient stations were readable.
- Chopping gave clear tactile feedback.
- Two players used clue objects; ticket currently made exploration optional.

## Recommendations

1. Keep timer but increase to eight minutes.
2. Award score bonus for inspecting clues.
3. Add stronger outlines to story props.
4. Keep chopping but reduce repetitions from six to three.
5. Test additional customer because one case did not reveal replay value.

## Caveat

This summary treats completion and system clarity as primary goals. Deloris recorded different qualitative concerns in the raw sheet.
