# UI notes — FINAL FINAL (for Friday capture)

- remove score from upper right
- remove visible countdown
- keep small dot reticle; Deloris wanted none but testers missed targets
- object name appears only after 0.4 sec focus
- “take” vs “inspect” needs different copy or icon
- bowl slots should not say CORRECT / WRONG
- end screen: show selected ingredients and one sentence from receipt printer
- no star rating
- accessibility: subtitle any radio/voicemail audio

Anthony question: Can internal debug show score? Yes, but release build should not.

Deloris question: Do we need inventory icons? Maybe three empty placements on counter, no floating HUD.
