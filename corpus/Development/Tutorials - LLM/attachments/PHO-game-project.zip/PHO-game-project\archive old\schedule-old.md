# PHO eight-week production schedule

Week 1 — ideation  
Week 2 — core cooking  
Week 3 — dialogue system  
Week 4 — customer 1 + 2  
Week 5 — customer 3 + 4  
Week 6 — progression / saves  
Week 7 — art + audio final  
Week 8 — Switch certification + launch

Team: Anthony (programming), Deloris (art/narrative), TBD audio, TBD QA.

No dates. Likely from first-draft GDD. Switch certification was never possible.
