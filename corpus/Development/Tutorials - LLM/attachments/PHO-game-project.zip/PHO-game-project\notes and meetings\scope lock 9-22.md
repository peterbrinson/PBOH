# Scope lock — Sept 22

Present: Anthony, Deloris  
Purpose: define the vertical slice we can finish.

## Locked for vertical slice

- Unity 2022.3 LTS + URP
- Windows PC
- first-person camera
- one restaurant room
- one absent customer represented through objects
- one 6–8 minute sequence
- three clues
- three ingredient decisions; noodles/protein may be pre-set
- no chopping minigame
- no player-facing timer
- no player-facing numeric score or correct/wrong labels
- three broad receipt endings based on story tags
- keyboard/mouse first; controller only if stable

## Kept under the hood

- ingredients remain data-driven
- debug scoring may help test ending thresholds
- analytics may record completion time during playtest

## Explicitly later / not promised

- additional customers
- overhead camera
- dialogue / voice acting
- WebGL, Mac, Switch
- save system

## Still unresolved

- literal ghost vs absence left unexplained
- public title
- whether player can make any combination or must fill one slot from each of three categories
- exact clue ↔ ingredient mapping

Both partners said yes. Anthony noted that he disagrees with cutting visible performance feedback but accepts it for this slice.
