# PHO / Night Service design doc

## Elevator pitch

A cozy overhead restaurant game where you serve ghosts until sunrise.

## Format

- Godot 4
- top-down 2.5D
- controller only
- five nights
- six customers per night
- unlock recipe cards
- dialogue portraits
- branching friendship values

## Core mechanic

Customers describe feelings instead of orders. Combine ingredients with emotional tags such as comfort, courage, apology, and celebration. There is no wrong bowl, but some combinations unlock more dialogue.

## Art

Hand-painted textures, miniature diorama, warm interior/cold exterior.

## Note

Anthony: We are not using Godot. This looks like the version from before kickoff. Why is it in design root again?
