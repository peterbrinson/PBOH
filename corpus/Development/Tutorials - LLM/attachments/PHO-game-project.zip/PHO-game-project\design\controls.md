# Controls — experience target

**Deloris / Sept 22**

Controller-first if possible:

- Left stick: move
- Right stick: look
- A / south button: inspect or pick up
- X / west button: place ingredient
- B / east button: step back / cancel
- Hold LT: focus on clue
- Menu: pause

No sprint. No crouch. Movement should be slightly slow but not “walking sim slow.”

Keyboard fallback:

- WASD move
- mouse look
- E interact
- Q place/back

Avoid separate controls for chop, pour, stir. The meaning is choosing and placing, not executing motor challenges.
