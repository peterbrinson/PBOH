# Anthony references

- *Papers, Please*: rules become legible through cases
- *The Case of the Golden Idol*: evidence supports a specific inference
- *Potion Craft*: ingredients with tags / authored combinations
- *Overcooked*: stations and action feedback
- *Hitman* (small slices): readable spaces support different approaches

What I want to study:

- player understands why an outcome occurred
- data makes content extensible
- replay reveals better interpretation
- input feedback is immediate

I do not want “narrative” to mean hidden answer that only makes sense after Deloris explains it.
