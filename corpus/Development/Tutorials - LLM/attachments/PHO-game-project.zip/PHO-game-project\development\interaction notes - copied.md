# Interaction notes copied from Anthony whiteboard

raycast → focus state → prompt → interaction

Need different verbs:

- inspect: does not move object, can reveal clue
- take: attaches ingredient to hand
- place: commits ingredient to bowl
- use: bell / light switch / receipt printer

Current E key does everything. This is okay if prompt names the action.

Question from D: can inspection change after another clue? Example: menu text changes meaning after receipt stack. Anthony says ClueState can support conditions but not by Friday.

Fast path: three clues become available in any order, no conditional text.
