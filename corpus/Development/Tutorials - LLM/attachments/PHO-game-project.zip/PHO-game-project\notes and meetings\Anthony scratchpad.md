# Anthony scratchpad

General system is 80% done. Cutting to one case does not reduce code much because ending still needs evaluation. It only reduces authored content.

Concern: If player cannot be wrong, clues have no mechanical meaning. “Interpretation” can become random selection plus poetic text. Need legibility and stakes.

Possible compromise:

- every bowl gets ending
- match to clue evidence changes specificity of ending
- internal fit score, never display number
- receipt language acknowledges strong match / surprising choice

Timer could be opt-in replay feature after first completion. Do not pitch now.

Deloris is right about chopping. It is fun for ten seconds but turns focus away from deduction. Keep branch in case later project needs tactile step.

Need ask D before using her moodboard images in application.
