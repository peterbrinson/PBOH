# Known bugs

## Blockers

- Deloris's materials render pink in Anthony's main project after 2023.2 import.
- EndingResolver expects five ingredient categories but new bowl has three slots.
- Build hangs if service bell is rung before inspecting any clue.

## High

- basil clue checks ingredient id `herb_mint`.
- countdown continues during pause.
- score screen appears even when `ShowScore` is false.
- controller cannot cancel bowl placement.
- receipt text overflows at 1280×720.

## Medium

- bell audio clips when clicked twice.
- umbrella focus outline can be seen through wall.
- player can sprint through counter corner.
- rain loop has audible seam.

## Unknown / design?

- translucent customer spawns at service. Deloris calls this a bug; Anthony calls it placeholder feedback.
- wrong ingredient turns slot red. Current design says choices should be interpreted, not marked wrong.

Last triage: Sept 30. No owner column because this came from chat.
