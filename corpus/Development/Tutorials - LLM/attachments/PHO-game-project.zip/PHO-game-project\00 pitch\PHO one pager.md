# PHO — one-page pitch

**Drafted:** Sept 4  
**Authors:** Anthony + Deloris

PHO is a short game about preparing the final bowl in a restaurant after closing. The customer is gone, but the traces they left behind—an umbrella, a folded receipt, a marked menu, a voicemail—suggest what they came for and why it mattered.

The player explores one small restaurant, reads the space, chooses ingredients, assembles a bowl, and places it at the last occupied table. The meaning of the order should emerge through action rather than an exposition dump.

## What we agree on

- one small restaurant at night
- ordinary objects carrying narrative weight
- preparing a bowl is the main action
- the ending changes how the player understands the customer
- 5–10 minute target

## Open

- first person or overhead
- literal ghost, implied memory, or living customer who is late
- one authored order or a system that supports several
- timer / no timer
- public title

Internal code name: PHO. Anthony says it means **Prepare, Heat, Offer**. Deloris does not remember agreeing to that.
