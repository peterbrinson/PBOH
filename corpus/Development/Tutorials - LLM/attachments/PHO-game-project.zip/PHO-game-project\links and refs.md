# links / refs / things somebody mentioned

- *Venba* — food as memory and relationship, not just optimization
- *Overcooked* — readable stations and handoffs, maybe the wrong emotional temperature
- *Unpacking* — meaning through objects and placement
- *The Red Strings Club* — conversation + making a thing for a person
- *What Remains of Edith Finch* — controlled authored sequence
- *Papers, Please* — learn a system through repeated cases (Anthony)
- *Gone Home* — inspect a place and infer people (Deloris)
- rainy restaurant ambience: saved in Deloris's bookmarks, not here
- font: Anthony wrote “Inter”; Deloris wrote “something warmer, maybe Fraunces”
- recipe research doc? I thought we had one

also see `references/games.md`, which is newer except when it isn't
