# Ingredient system notes

**Anthony, Sept 19**

Need a general representation even if vertical slice has one customer.

Each ingredient has:

- id
- display name
- category (broth / noodle / protein / herb / garnish)
- flavor tags (warm, sharp, rich, fresh, familiar)
- story tags (routine, change, memory, risk)
- prefab reference
- icon

Customer preference can weight tags. Ending can inspect total tags rather than exact recipe. This would let Deloris author three ending tones without writing all combinations.

Potential issue: design only wants three choices, but data currently requires one item in five categories. Options:

1. pre-fill noodles and protein automatically
2. reduce categories for vertical slice
3. keep five decisions because the system is already built

I prefer 3; scope meeting seems to say 1 or 2.
