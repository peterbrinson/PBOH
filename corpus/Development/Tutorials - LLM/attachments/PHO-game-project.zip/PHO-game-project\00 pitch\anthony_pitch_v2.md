# PHO: After Hours

**Anthony — Sept 7**

A first-person cooking deduction game. Each night, a strange customer leaves incomplete clues. The player inspects the restaurant, builds the most likely bowl from a modular ingredient system, and earns a rating based on accuracy, speed, and waste.

## Hook

*Papers, Please* meets a compact cooking sim. Learn the language of the restaurant through repeatable cases.

## Prototype

- three customers
- six-minute shift
- twelve ingredients
- recipe tags rather than hard-coded recipes
- ticket, prep, assemble, serve
- score: customer fit + time + waste
- replay to discover better solutions

## Why it works

The system makes the story playable. A single scripted order is content-heavy and cannot prove the mechanic has depth. If we build the data model now, Deloris can author more customers without code.

Potential title: **PHO: After Hours**. Clear and searchable.
