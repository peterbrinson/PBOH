# Narrative beats

VERSION FROM BEFORE WE CUT DIALOGUE — possibly Sept 11

1. Customer enters at 11:57 p.m. and refuses menu.
2. Player asks three dialogue questions.
3. Customer answers with fragments about train station.
4. Player cooks while customer tells story.
5. Customer is revealed as previous owner's daughter.
6. Player chooses to charge her or comp meal.
7. Exterior cinematic: restaurant sign turns off.

Needed: full dialogue, customer character, facial animation, VO, train-station cutaway.

Deloris note: none of this works with our skills/time. Keep only the train tag on the umbrella and the light turning off.

Anthony note: dialogue could be text only and solve clue legibility.
