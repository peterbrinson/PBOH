# Anthony

## Comfortable with

- Unity and C# gameplay scripting
- ScriptableObjects / data-driven systems
- first-person interaction
- UI implementation
- profiling and Windows builds
- spreadsheets, tickets, naming conventions

## Less comfortable with

- character animation
- final lighting and materials
- writing dialogue
- estimating content production

## Working preferences

- morning work blocks
- decisions in writing
- one source-of-truth GDD
- task lists with owners and definitions of done
- prototype the general system before polishing one example

Anthony sometimes keeps a local working copy until a feature is stable. This has already caused two project-version mismatches.
