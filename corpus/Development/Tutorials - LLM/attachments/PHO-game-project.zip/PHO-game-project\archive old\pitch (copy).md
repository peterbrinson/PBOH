# LAST BOWL

A 20-minute narrative adventure in which a cook serves three ghosts on the final night of a family restaurant.

Copied from festival draft before scope lock. The line about “final night of a family restaurant” appears nowhere else and may have been invented for pitch drama.
