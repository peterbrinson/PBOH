# Core loop options

No date. Initials indicate advocate, not ownership.

## A — ticket loop (A)

ticket → inspect → prep → assemble → serve → grade → next ticket

Good: readable, replayable, proves system.  
Risk: feels like a productivity test.

## B — memory loop (D)

notice object → infer relationship → choose ingredient → change room → notice again

Good: every action carries story.  
Risk: hard to tell whether the player understands the interaction.

## C — current hybrid (?)

explore table → collect three clues → make three ingredient decisions → assemble → ring bell → receive contextual ending

Good: buildable and can retain data-driven reactions.  
Risk: if clues map one-to-one to ingredients, the story becomes a combination lock.

Question: Is the goal to deduce the customer's usual order, or decide what to make for them tonight? Those are different games.
