# Sprint 2 board — copied Sept 29

## Doing

- [Anthony] three-slot bowl refactor
- [Anthony] remove old customer spawner
- [Deloris] restaurant lighting merge
- [Deloris] window-table clues

## Review

- ending receipt text
- inspect / take prompt language
- basil versus mint

## Blocked

- lighting merge — Unity version mismatch
- final music — license / composer availability
- controller — cancel action undefined

## Backlog

- three customers
- score tuning
- WebGL
- voiced dialogue
- randomized tickets
- save discovered clues
- Switch build

The backlog is not a promise. Anthony keeps moving three-customer tasks back into Doing because “the architecture is already there.”
