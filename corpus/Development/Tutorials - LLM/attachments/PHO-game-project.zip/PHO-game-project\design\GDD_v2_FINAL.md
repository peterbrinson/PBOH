# LAST BOWL — experience design

**Presented at scope meeting:** Sept 22  
**Compiled by:** Deloris  
**Status:** FINAL for vertical slice presentation

## The experience

After closing, the player prepares one final bowl for the person who always sat by the rain-streaked window. The person never appears directly. The player learns them by noticing what remains in the restaurant.

The restaurant is not a task arena. It is a place where repetition has accumulated meaning.

## Intended arc

1. **Routine:** Turn on the last light, hear rain, find the unclosed check.
2. **Attention:** Inspect the window table and discover three clues.
3. **Interpretation:** Choose broth, herb, and garnish. Choices express what the player thinks the customer needed.
4. **Care:** Assemble the bowl with deliberate, simple actions.
5. **Absence:** Ring the bell. No one arrives. The receipt printer produces a final line.

## Current scope

- one 6–8 minute authored sequence
- one restaurant
- three meaningful ingredient choices
- no chopping or dexterity minigames
- no timer, score, or fail state
- first-person for the vertical slice; overhead camera remains a later test
- Windows PC
- keyboard/mouse required; controller is a stretch goal
- Unity URP

## Design constraint

The player should be able to explain what they inferred and point to evidence. The ending may differ based on the bowl, but it should not announce a correct recipe with points.

## Unresolved

- Is the absent customer dead, gone, or simply late?
- Does the final receipt adapt to every ingredient combination or to three broad interpretations?
- Public title: **Last Bowl** or **PHO: After Hours**.

Related: [[scope lock 9-22]], [[clues and bowl meanings]].
