# Playtest 2 field notes — Sept 28

Build 0.3-ish, 3-slot bowl, no visible ticket. Timer UI was hidden but still rang alarm at four minutes.

T1
- found umbrella and menu
- chose spiced / basil / lime
- said customer “wanted to break a habit but still come home”
- ghost placeholder made them assume customer died; before that they thought customer left town

T2
- missed receipts because highlight through wall led to menu first
- chose all familiar tags
- could explain choices
- expected bell to call a living customer from outside

T3
- tried to put five ingredients in bowl because empty protein/noodle stations looked active
- liked no chopping
- asked whether one combination was correct

Questions to ask next:
- Does receipt ending feel responsive or evaluative?
- Should absent customer remain ambiguous?
- Can unused stations be dressed as unavailable rather than broken?
