# Deloris — mood and experience references

- *Unpacking*: an object has meaning because of its neighbors
- *Venba*: cooking gesture can hold memory
- *Florence*: ordinary interaction changes emotional weight
- *What Remains of Edith Finch*: authored sequence and controlled attention
- *The Red Strings Club*: making something is a way to understand a person
- Wong Kar-wai restaurant interiors — rain, glass, waiting, saturated practical lights

Things to avoid:

- generic “cozy game” clutter
- neon cyberpunk noodle shop
- ghost customer with blue transparency
- reward sparkles over food
- text logs explaining every prop

The room should feel tended but tired. Warm is not the same as cute.
