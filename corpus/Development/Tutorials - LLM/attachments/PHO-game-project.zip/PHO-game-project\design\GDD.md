# PHO game design document

**Last edited:** Sept 10  
**Maintainer:** Anthony

## Summary

PHO is a replayable first-person cooking deduction game. During each shift, the player serves unusual customers by matching ingredients to clues found in the restaurant.

## Pillars

1. **Read the customer.** Clues reveal taste, history, and mood.
2. **Build the bowl.** Ingredients combine through a tag-based recipe system.
3. **Own the result.** Service is scored; the customer reacts; the next run invites improvement.

## Core loop

1. Receive a ticket.
2. Inspect three environmental clues.
3. Collect broth, noodles, protein, herbs, and garnish.
4. Complete one short prep interaction per ingredient.
5. Assemble and serve before the six-minute shift ends.
6. Review score and customer reaction.

## Prototype scope

- first-person
- three customers
- twelve ingredients
- three prep minigames: chop, pour, stir
- one restaurant scene
- Windows and WebGL
- keyboard/mouse, controller later

## Failure

The shift ends when time expires. The customer leaves, but discovered clues persist between attempts.

## Status

Core ingredient data structure exists. Interaction raycast works. Narrative content is waiting on Deloris.

See `development/ingredient_data_schema.json` and `planning/schedule.csv`.
