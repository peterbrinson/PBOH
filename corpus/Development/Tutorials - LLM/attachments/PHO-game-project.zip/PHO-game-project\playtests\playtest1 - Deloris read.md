# What I saw in playtest 1

**Deloris — Sept 17**

Everyone could make a bowl because the ticket stated the answer and the UI highlighted every step. That does not yet test our intended experience.

- Timer caused at least two players to stop looking at the room.
- Three players described chopping as the main game, though clues are supposed to be central.
- P4 formed a story about the umbrella when given time.
- P2 chose ingredients based on mood, not ticket, and then thought the red feedback meant they failed the story.
- Nobody connected the receipts across years because inspection text was too long and appeared while countdown continued.

Next test should remove ticket recipe, visible timer, and correct/wrong feedback. Ask players afterward: Who was the order for? What did you notice? Why did you choose those ingredients?
