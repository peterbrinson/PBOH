# How to run the current prototype

There is no build in this handoff folder. This file describes the copy on Anthony's PC.

1. Install Unity Hub.
2. Install Unity **2022.3.41f1** with Windows Build Support.
3. Open `PHO_Main`.
4. Open `Assets/Scenes/Restaurant_Blockout.unity`.
5. Press Play.

If all materials are pink, import the URP sample materials from Deloris's Drive folder. Do not use the `Restaurant_Lighting` scene unless you upgrade to 2023.2.

Build menu target: Windows / Intel 64-bit.

Note: `tech-plan.md` says 2022.3.48f1, not 41f1. I do not know which patch Anthony actually used. Unity Hub screenshot in chat showed 48f1.
